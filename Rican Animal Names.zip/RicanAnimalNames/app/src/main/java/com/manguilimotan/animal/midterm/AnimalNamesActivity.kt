package com.manguilimotan.animal.midterm

import android.content.SharedPreferences
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.manguilimotan.animal.midterm.adapters.AnimalListAdapter
import com.manguilimotan.animal.midterm.databinding.ActivityAnimalNamesBinding
import com.manguilimotan.animal.midterm.models.Animal

class AnimalNamesActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAnimalNamesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAnimalNamesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPreferences: SharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        val blockedAnimalsSet = sharedPreferences.getStringSet("blockedAnimals", HashSet()) ?: HashSet()
        val blockedAnimalsList = blockedAnimalsSet.toList()

        val animalList: MutableList<Animal> = mutableListOf(
            Animal("Alligator", "Large reptiles with a long body and a broad snout, known for living in freshwater habitats.", false),
            Animal("Bear", "Mammals that are large and powerful, found in various habitats around the world.", false),
            Animal("Cat", "Domesticated or wild feline animals known for their agility and independence.", false),
            Animal("Dolphin", "Marine mammals known for their intelligence and playful behavior, typically found in oceans.", false),
            Animal("Elephant", "Large mammals with a long trunk and tusks, found in Africa and Asia.", false),
            Animal("Fox", "Small to medium-sized mammals with bushy tails, known for their cunning and adaptability.", false),
            Animal("Gorilla", "Primates that are closely related to humans and are known for their strength and social behavior.", false),
            Animal("Horse", " Large hoofed mammals often used for riding, racing, and as work animals.", false),
            Animal("Iguana", "Reptiles known for their long tails and spiky crests, found in tropical regions.", false),
            Animal("Jaguar", " Large wild cats known for their powerful build and distinctive rosette-patterned coat.", false),
            Animal("Kangaroo", " Marsupials native to Australia known for their powerful hind legs and jumping ability.", false),
            Animal("Lion", " Large cats found in Africa, known for their social behavior and the king of the jungle reputation.", false),
            Animal("Monkey", "Primates with long tails, known for their agility and intelligence.", false),
            Animal("Newt", "Small amphibians that can live in water and on land, often brightly colored.", false),
            Animal("Octopus", "Marine mollusks with soft bodies, known for their intelligence and multiple arms.", false),
            Animal("Penguin", "Flightless birds found in the Southern Hemisphere, known for their tuxedo-like appearance.", false),
            Animal("Quokka", "Small marsupials native to Australia, known for their friendly and smiling appearance.", false),
            Animal("Rabbit", "Small mammals known for their long ears and rapid breeding.", false),
            Animal("Snake", "Legless reptiles known for their slithering movement and a wide variety of species.", false),
            Animal("Tiger", "Large wild cats known for their orange coat with black stripes and strength.", false),
            Animal("Urutu", "A venomous pit viper snake found in South America, known for its striking appearance.", false),
            Animal("Vulture", " Large birds of prey that feed on carrion, known for their scavenging habits.", false),
            Animal("Walrus", "Marine mammals with large tusks, found in Arctic regions.", false),
            Animal("X-ray", "A small, translucent fish with a red spot on its body, named for its appearance on X-ray.", false),
            Animal("Yak", " Large, domesticated mammals found in the Himalayan region, known for their shaggy coats.", false),
            Animal("Zebra", "Striped equids found in Africa, known for their distinctive black and white stripes.", false),
        )

        animalList.sortBy { it.name }

        val context = this
        val adapter = AnimalListAdapter(animalList, context)

        val filteredAnimals = animalList.filterNot { blockedAnimalsList.contains(it.name) }
        adapter.updateData(filteredAnimals)

        val recyclerView = binding.animalNames
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        val manageBlockButton = binding.mngBtn
        manageBlockButton.setOnClickListener {
            val intent = Intent(this, ManageBlockActivity::class.java)
            startActivity(intent)
        }
    }
}